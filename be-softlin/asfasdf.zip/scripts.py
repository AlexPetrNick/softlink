def func3():
    return 'asd'

class List:
    tenp = 1

    def func(self, **kwargs):
        self.tl = 123123



a = List().func()
print(a.tl)