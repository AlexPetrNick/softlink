from django.db import models


class Socket(models.Model):
    name = models.TextField(max_length=50)

    def __str__(self):
        return self.name


class CoreAMD(models.Model):
    name = models.TextField(max_length=50)

    def __str__(self):
        return self.name


class CoreINTEL(models.Model):
    name = models.TextField(max_length=50)

    def __str__(self):
        return self.name


class Brand(models.Model):
    name = models.TextField(max_length=50)
    description = models.TextField(max_length=300, blank=True)

    def __str__(self):
        return self.name


class SocketMother(models.Model):
    name = models.TextField(max_length=50)

    def __str__(self):
        return self.name


class ChipsetIntel(models.Model):
    name = models.TextField(max_length=50)
    description = models.TextField(max_length=300, blank=True)

    def __str__(self):
        return self.name


class ChipsetAmd(models.Model):
    name = models.TextField(max_length=50)
    description = models.TextField(max_length=300, blank=True)

    def __str__(self):
        return self.name


class FormFactor(models.Model):
    name = models.TextField(max_length=50)
    description = models.TextField(max_length=300, blank=True)

    class Meta:
        abstract = True


class FormFactorMother(FormFactor):
    def __str__(self):
        return self.name


class FormFactorRam(FormFactor):
    def __str__(self):
        return self.name


class FormFactorPowerSupply(FormFactor):
    def __str__(self):
        return self.name


class FormFactorSsd(FormFactor):
    def __str__(self):
        return self.name


class Image(models.Model):
    image = models.ImageField()


class Processor(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    series = models.TextField(max_length=20)
    model = models.TextField(max_length=20)
    socket = models.ForeignKey(Socket, on_delete=models.CASCADE)
    freq = models.TextField(max_length=20)
    core_int = models.ForeignKey(CoreINTEL, on_delete=models.CASCADE)
    core_amd = models.ForeignKey(CoreAMD, on_delete=models.CASCADE)
    tech_proc = models.TextField(max_length=20)
    num_core = models.TextField(max_length=20)
    cache1 = models.IntegerField()
    cache2 = models.IntegerField()
    tdp = models.TextField(max_length=20)
    has_graph = models.BooleanField()
    image = models.ForeignKey(Image, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.series)


class HDD(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    form_factor = models.TextField(max_length=30)
    memory = models.TextField(max_length=30)
    buffer = models.TextField(max_length=30)
    freq = models.TextField(max_length=30)
    interface = models.TextField(max_length=30)
    propusk_sposob = models.TextField(max_length=30)
    power = models.TextField(max_length=30)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)


class Mother(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    socket = models.ForeignKey(SocketMother, on_delete=models.CASCADE)
    chipsetI = models.ForeignKey(ChipsetIntel, on_delete=models.CASCADE)
    chipsetA = models.ForeignKey(ChipsetAmd, on_delete=models.CASCADE, null=True, blank=True)
    work_freq = models.TextField(max_length=30)
    ddr3 = models.TextField(max_length=30)
    ddr4 = models.TextField(max_length=30)
    pcie1 = models.TextField(max_length=30)
    pcie8 = models.TextField(max_length=30)
    pcie16 = models.TextField(max_length=30)
    port = models.TextField(max_length=150)
    bios = models.TextField(max_length=30)
    form_fact = models.ForeignKey(FormFactorMother, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)


class RAM(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    type_memory = models.TextField(max_length=30)
    memory = models.TextField(max_length=30)
    form_factor = models.ForeignKey(FormFactorRam, on_delete=models.CASCADE)
    work_freq = models.TextField(max_length=30)
    timing = models.TextField(max_length=30)
    latency = models.TextField(max_length=30)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)


class VideoCard(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    tech_proc = models.TextField(max_length=30)
    series = models.TextField(max_length=30)
    graph_proc = models.TextField(max_length=30)
    freq_proc = models.TextField(max_length=30)
    threading = models.TextField(max_length=30)
    type_memory = models.TextField(max_length=30)
    size_shina_video = models.TextField(max_length=30)
    freq_videomemory = models.TextField(max_length=30)
    api = models.TextField(max_length=30)
    connector = models.TextField(max_length=30)
    port = models.TextField(max_length=30)
    added_power = models.TextField(max_length=30)
    power = models.TextField(max_length=30)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)


class PowerSupply(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    form_factor = models.ForeignKey(FormFactorPowerSupply, on_delete=models.CASCADE)
    power_all = models.TextField(max_length=30)
    PFC = models.TextField(max_length=30)
    int_for_mother = models.TextField(max_length=30)
    molex = models.TextField(max_length=30)
    sata = models.TextField(max_length=30)
    fdd = models.TextField(max_length=30)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)


class SSD(models.Model):
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    model = models.TextField(max_length=30)
    type_mem = models.TextField(max_length=30)
    form_factor = models.ForeignKey(FormFactorSsd, on_delete=models.CASCADE)
    memory = models.TextField(max_length=30)
    speed_read = models.TextField(max_length=30)
    speed_write = models.TextField(max_length=30)
    interface = models.TextField(max_length=30)
    propusk_sposob = models.TextField(max_length=30)
    power_in = models.TextField(max_length=30)

    def __str__(self):
        return str(self.brand) + ' ' + str(self.model)