from django.db.models import Q
from django.db.models.query import QuerySet
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.template.loader import get_template
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.views import generic, View
from .models import HDD
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import HddListSerializers

class HddListView(APIView):
    """Вывод HDD"""
    def get(self, request):
        hdd = HDD.objects.all()
        serializer = HddListSerializers(hdd, many=True)
        return Response(serializer.data)
"""
def get_main_page(request):
    return render(request, 'news.html')

def registration(request):
    return render(request, 'registration.html')


def unlog(request):
    logout(request)
    return HttpResponseRedirect('/')


class LoginView(View):

    def post(self, request, *args, **kwargs):
        dict_user = self.request.POST.dict()
        username = dict_user['username']
        password = dict_user['password']
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return HttpResponseRedirect('/')

class HddListView(generic.ListView):
    model = HDD
    paginate_by = 18
    template_name = 'hdd.html'
    context_object_name = 'hdd'
    paginate_orphans = 18

    def get_queryset(self):
        obj_set = HDD.objects
        filter_temp = self.request.GET.getlist('memory')
        if filter_temp:
            self.queryset = obj_set.filter(memory__in=filter_temp)
            print(self.queryset)
        else:
            self.queryset = obj_set.all()
        return self.queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        number_page = len(self.request.GET)
        if number_page:
            number_page = self.request.GET['page']
        else:
            number_page = 1
        paginator = context['paginator']
        context['req'] = dir(self.request.user)
        context['items'] = paginator.page(number_page)
        context['pages'] = paginator.page_range
        context['filters_mem'] = HDD.objects.values('memory').distinct()
        context['filters_ff'] = HDD.objects.values('form_factor').distinct()
        return context


class CpuListView(generic.ListView):
    model = Processor
    paginate_by = 18
    template_name = 'cpu.html'
    context_object_name = 'cpu'
    paginate_orphans = 18

    def get_queryset(self):
        request_self = self.request.GET.getlist
        qr_self = Processor.objects
        if request_self("socket"):
            socket = Socket.objects.filter(name__in=request_self("socket"))
        else:
            socket = qr_self.all().values('socket')
        if request_self("core_amd"):
            core_amd = CoreAMD.objects.filter(name__in=request_self("core_amd"))
        else:
            core_amd = qr_self.all().values('core_amd')
        if request_self("core_int"):
            core_int = CoreINTEL.objects.filter(name__in=request_self("core_int"))
        else:
            core_int = qr_self.all().values('core_int')
        if request_self("tech_proc"):
            tech_proc = qr_self.filter(tech_proc__in=request_self("tech_proc")).values('tech_proc')
        else:
            tech_proc = qr_self.all().values('tech_proc')
        print(request_self("has_graph"))
        if request_self("has_graph"):
            has_graph = qr_self.filter(has_graph__in=request_self("has_graph")).values('has_graph')
        else:
            has_graph = qr_self.all().values('has_graph')
        queryset = Processor.objects.filter(
            Q(socket__in=socket),
            Q(core_amd__in=core_amd),
            Q(core_int__in=core_int),
            Q(tech_proc__in=tech_proc),
            Q(has_graph__in=has_graph)
        )
        return queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        page_request = self.request.GET
        number_page = 0
        if 'page' in page_request.keys():
            number_page = page_request['page']
        else:
            number_page = 1
        paginator = context['paginator']
        context['items'] = paginator.page(number_page)
        context['pages'] = paginator.page_range
        context['socket'] = Socket.objects.values('name').distinct().exclude(name='No')
        context['core_int'] = CoreINTEL.objects.values('name').distinct().exclude(name='No')
        context['core_amd'] = CoreAMD.objects.values('name').distinct().exclude(name='No')
        context['tech_proc'] = Processor.objects.values('tech_proc').distinct()
        context['has_graph'] = Processor.objects.values('has_graph').distinct()
        return context


class MotherListView(generic.ListView):
    model = Mother
    paginate_by = 18
    template_name = 'mother.html'
    context_object_name = 'mother'
    paginate_orphans = 18

    def get_queryset(self):
        request_self = self.request.GET.getlist
        qr_self = Mother.objects
        queryset = qr_self.all()
        return queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        page_request = self.request.GET
        number_page = 0
        if 'page' in page_request.keys():
            number_page = page_request['page']
        else:
            number_page = 1
        paginator = context['paginator']
        context['items'] = paginator.page(number_page)
        context['pages'] = paginator.page_range
        context['socket'] = Socket.objects.values('name').distinct().exclude(name='No')
        context['core_int'] = CoreINTEL.objects.values('name').distinct().exclude(name='No')
        context['core_amd'] = CoreAMD.objects.values('name').distinct().exclude(name='No')
        context['tech_proc'] = Processor.objects.values('tech_proc').distinct()
        context['has_graph'] = Processor.objects.values('has_graph').distinct()
        return context
"""
