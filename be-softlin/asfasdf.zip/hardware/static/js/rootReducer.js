export function rootReducer(state, action) {
	if (action.type === 'INCREMENT') {

	} else if (action.type)

	return state
}