from rest_framework import serializers
from .models import HDD


class HddListSerializers(serializers.ModelSerializer):
    """Сериализация HDD"""

    class Meta:
        model = HDD
        fields = ("brand", "model", "form_factor", "memory", "memory")

