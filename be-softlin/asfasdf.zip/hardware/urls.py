from django.conf import settings
from django.core import paginator
from django.conf.urls.static import static
from django.urls import include, path
from django.conf.urls import url
from . import views

urlpatterns = [
    path("hdd/", views.HddListView.as_view())
]