import React from 'react';

const PictureUp = () => {
	return (
		<div className="picture__in__up"></div>	
	);
}

export default PictureUp;