import React from "react";
import {NavLink} from "react-router-dom";

const MenuWrapper = () => {
	return (
	<div className="menu__wrapper">
			<div className="empty__menu"></div>
			<ul className="list__menu">
				<li className="news__menu"><a href="{% url 'index_main' %}" className="text__menu">Новости</a></li>
				<li className="hardware__menu"><a href="#" className="text__menu">Железо</a>
						<div className="list__menu__hardware">
						<ul className="sub-list__menu__hardware">
							<li className="item__hardware"><NavLink to="/hardware/hdd">Жесткий диск</NavLink></li>
							<li className="item__hardware"><NavLink to="/hardware/cpu">Процессоры</NavLink></li>
							<li className="item__hardware"><a href="">Материнская плата</a></li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
							<li className="item__hardware">lorem</li>
						</ul>
						</div>
				</li>	
				<li className="notebook__menu text__menu">Ноутбуки&otimes;</li>
				<li className="prog__menu text__menu">Программа&otimes;</li>
			</ul>
			<div className="empty__menu"></div>
		</div>
		);
}

export default MenuWrapper;