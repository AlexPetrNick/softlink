import React from 'react';
import './App.css';
import {BrowserRouter, Route} from 'react-router-dom';
import UserControl from './userControl/userControl.js';
import PictureUp from './pictureUp/PitureUp.js';
import MenuWrapper from './menuWrapper/MenuWrapper.js';
import FooterWrapper from './footerWrapper/footerWrapper.js';
import AddedMenu from './added/AddedMenu.js';
import CpuPage from './contentWrapper/Cpu/Cpu.jsx'
import HddPage from './contentWrapper/Hdd/Hdd.jsx'

function App() {
    console.log('USERVONTROL', UserControl)
  return (
    <BrowserRouter>
        <div className="wrapper">
        	<UserControl />
        	<PictureUp />
        	<MenuWrapper />
        	<div className="content__wrapper">
    	    	<div></div>
                <Route exact path="/hardware/cpu" component={CpuPage}/>
                <Route path="/hardware/hdd" component={HddPage}/>
    	    	<div></div>
        	</div>
        	<FooterWrapper />
        	<AddedMenu />
        </div>
    </BrowserRouter>
  );
}

export default App;
