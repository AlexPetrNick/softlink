import React from 'react';

const UserControl = () => {
	return (
		<div className="session___control">
			<div className="fill__left"></div>
			<div className="login__part">
				<div className="site__name__label">SoftLink</div>
				<div className="status__auth">user</div>
				<div className="income__auth"><a href="#">Выход?</a></div>
				<div className="registration__menu">
					<div className="button__registraton"><a className="notst__link__green" href="#">Кабинет</a></div>
				</div>
			</div>
			<div className="fill__right"></div>
		</div>
	);
}


export default UserControl;