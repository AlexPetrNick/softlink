import React from 'react'
import ItemHard from '../ItemHard/ItemHard.jsx'

const HddPage = () => {

	let dataItemHard = [
		{
			title: 'WD',
			memory: '1tb',
			buffer: '256',
			frequency: '1600',
			formfact: '3.5',
			interface: 'SATA',
			propusk: '34'
		},
		{
			title: 'WD2',
			memory: '2tb',
			buffer: '512',
			frequency: '1900',
			formfact: '3.5',
			interface: 'SATA',
			propusk: '341'
		}
	]

	let ListItemHards = dataItemHard.map(d => <ItemHard data={d.title} /> );
	let ListItemHard = () => {
		return (
			<ItemHard data={dataItemHard[0].title} />
		);
	}

	console.log(ListItemHard)
	console.log(ItemHard)
	return (
		<div className="wrapper__hard">

			<div className="content___list">

				<div className="page_content">
					<ListItemHard />
					{ListItemHards	}
				<div className="page__number__list">
					<div className="empty"></div>
						<ul className="page__slot">
							<li className="prev__page"><a href="#">Пред.</a></li>
							<li className="number__page"><a href="#">3</a></li>
							<li className="next__page"><a href="#">След.</a></li>
						</ul>
					<div className="empty"></div>
				</div>
			</div>

			<div className="filter__list">
				<form action="#" method="GET" id="filter__memory">
					<div className="filter__body">
						<div className="filter__item__title">Память</div>
							<div className="filter__item">
								<input id="check" type="checkbox" name="memory" value="12" /> 12
							</div>
					</div>
					<input type="submit" />
				</form>
				<form action="#" method="GET" id="filter__formfactor">
					<div className="filter__body">
						<div className="filter__item__title">Память</div>
							<div className="filter__item">
								<input type="checkbox" name="form_factor" value="12" /> 12
							</div>
					</div>
					<input type="submit" />
				</form>
			</div>
		</div>
	</div>
	);
}

export default HddPage