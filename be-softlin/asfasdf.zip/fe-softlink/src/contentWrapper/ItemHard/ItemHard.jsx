import React from 'react'

const ItemHard = () => {
	return (
		<div className="item__content">
						<img className="picture__hard_item" src="#" alt="" />
						<div className="title__hard__item">data.title</div>
						<div className="description__hard__item">
							<strong>Память: </strong>
							<span>data.memory</span>
							<strong>Буфер: </strong>
							<span>data.buffer</span>
							<strong>Частота: </strong>
							<span>data.frequency</span>
							<strong>Форм-фактор: </strong>
							<span>data.formfact</span>
							<strong>Интерфейс: </strong>
							<span>data.interface</span>
							<strong>Пропускная способность: </strong>
							<span>data.propusk</span>
						</div>
						<div className="menu__hard__item">
							<div className="menu__hard__see">&raquo;</div>
							<div className="menu__hard__add">+</div>
							<div className="menu__hard__corr">&#9998;</div>
						</div>
					</div>
	);
}


export default ItemHard