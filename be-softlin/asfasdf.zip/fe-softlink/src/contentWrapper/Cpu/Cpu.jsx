import React from 'react'

const CpuPage = () => {
	return (
		<div className="wrapper__hard">
			<div className="content___list">
				<div className="page_content">
					<div className="item__content">
						<img className="picture__hard_item" src="" alt="" />
						<div className="title__hard__item">AMD 100500</div>
						<div className="description__hard__item">
							<strong>Cерия: </strong>
							<span>X7450 </span>
							<strong>Сокет: </strong>
							<span>AM4 </span>
							<strong>Частота: </strong>
							<span>3100VUW </span>
							<strong>Ядро AMD: </strong>
							<span>Zen2 </span>
							<strong>Кол-во ядер: </strong>
							<span>4 </span>
							<strong>Тех.процесс: </strong>
							<span>7нм </span>
						</div>
						<div className="menu__hard__item">
							<div className="menu__hard__see">&raquo;</div>
							<div className="menu__hard__add">+</div>
							<div className="menu__hard__corr">&#9998;</div>
						</div>
					</div>
				</div>
				<div className="page__number__list">
					<div className="empty"></div>
						<ul className="page__slot">
							<li className="prev__page"><a href="">Пред.</a></li>
							<li className="number__page"><a href="#">3</a></li>
							<li className="next__page"><a href="">След.</a></li>
						</ul>
					<div className="empty"></div>
				</div>
			</div>

			<div className="filter__list">
				<form id="filter" action="#" method="GET">
					<div className="filter__body">
						<div className="filter__item__title">Сокет</div>
						<div className="filter__item">
							<input type="checkbox" name="socket" value="Socket" />Socket
						</div>
					</div>
					<div className="filter__body">
						<div className="filter__item__title">Ядро Intel</div>
						<div className="filter__item">
							<input type="checkbox" name="core_int" value="Intel" />Intel
						</div>
					</div>
					<div className="filter__body">
						<div className="filter__item__title">Ядро AMD</div>
						<div className="filter__item">
							<input type="checkbox" name="core_amd" value="AMD" />AMD
						</div>
					</div>
					<div className="filter__body">
						<div className="filter__item__title">Тех. процесс</div>
						<div className="filter__item">
							<input type="checkbox" name="tech_proc" value="14yv" />14yv
						</div>
					</div>
					<div className="filter__body">
						<div className="filter__item__title">Встроенный графический процессор</div>
						<div className="filter__item">
							<input type="checkbox" name="has_graph" value="No" />
						</div>
					</div>
					<input type="submit" />
				</form>
			</div>
		</div>
	);
}

export default CpuPage