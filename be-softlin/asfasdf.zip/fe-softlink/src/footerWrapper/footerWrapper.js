import React from 'react';

const FooterWrapper = () => {
	return (
	<div class="footer__wrapper">6</div>
	);
}

export default FooterWrapper;